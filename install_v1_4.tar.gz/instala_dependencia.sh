#!/bin/bash
#Instala  app
#Revisar si existe la app


#revisa si es root
if [ ${UID} -ne "0" ]; then
  echo -e "Utiliza $0 como root ... o \n sudo $0" 
  exit 1
fi
#revisa si hay argumento
if [ "$#" -ne "1" ]; then 
  echo -e "Utiliza $0 [comando_instalar]"
  exit 1
fi

#Buscamos si existe el ejecutable
echo "Buscando $1 ..."
result=$(sudo find / -name $1 2>/dev/null |wc -l)
echo "Se encontraron  $result coincidencias de $1"

if [ ${result} == "0" ]; then
  echo "No se a encontrado el comando $1 ... se procede a instalar"
  sudo apt-get -y install $1 
else 
   echo -e "...$1 ya está instalado en el sistema\n"
fi

