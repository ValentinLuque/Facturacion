#!/bin/bash
#Añade un cliente

fecha=$(date +%Y%m%d); segundos=$(date +%s); segundos=${segundos:7:3}
#Creamos un random del codigo de cliente a partir de la fecha y los ultimos segundos
CCLIENTE=$fecha$segundos

EXE=$(yad --title="Cliente" --separator="|" --geometry="400x200" --form \
  --field="Nombre: " \
  --field="Dirección: " \
  --field="Población: " \
  --field="C.P.: " \
  --field="email: " \
  --field="Telf: "\
  
)
if [ ${?} -eq "0" ]; then
  #Agregamos el registro a la bbdd

#Pone comillas en el campo que queramos
#Primer parámetro la columna dónde poner las comillas 
#segundo el separadaro tercero la cadena  donde agregarlas 
  
  #agregar_comillas 2 : "${EXE}" 
  echo $CCLIENTE\|$EXE>>clientes.dat 
   
fi
