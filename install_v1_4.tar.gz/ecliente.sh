#!/bin/bash
#Edita un cliente

FICH="clientes.dat"
awk -F "|" '{print $2 }' $FICH >fich.tmp

#Crea un fichero temporal
#utilizar paste para pasarlo en el formato fila en vez de columna
EXE=$(yad --separator="|" --form --item-separator="|" --geometry="300x50" \
--field="Nombre:"CE  "$(paste -s -d"|" <fich.tmp)" )

#Eliminamos el ultimo caracter de la cadena con POSIX
CLIENTE=${EXE%?}
echo $CLIENTE

#Buscamos el cliente para modificar
CODIGO=$(grep "${CLIENTE}" $FICH|cut -d\| -f1)
DIRECCION=$(grep "${CLIENTE}" $FICH|cut -d\| -f3)
POBLACION=$(grep "${CLIENTE}" $FICH|cut -d\| -f4)
CP=$(grep "${CLIENTE}" $FICH|cut -d\| -f5)
EMAIL=$(grep "${CLIENTE}" $FICH|cut -d\| -f6)
TELF=$(grep "${CLIENTE}" $FICH|cut -d\| -f7)

#echo -e "El codigo del cliente $CLIENTE es $CODIGO\nLa direccion es $DIRECCION"

EXE=$(yad --title="Cliente a modificar o borrar" --separator="|" --geometry="400x200" --form \
  --field="Nombre: " "$CLIENTE" \
  --field="Dirección: " "$DIRECCION" \
  --field="Población: " "$POBLACION" \
  --field="C.P.: " "$CP" \
  --field="email: " "$EMAIL" \
  --field="Telf: " "$TELF" \
  --button="Editar:0" \
  --button="Borrar:1" )

if [ "${?}" -eq "0" ]; then
 #editamos
 #echo ${EXE}
 CLIENTE=$(echo $EXE | awk -F "|" '{print $1}')
 DIRECCION=$(echo $EXE | awk -F "|" '{print $2}')
 POBLACION=$(echo $EXE | awk -F "|" '{print $3}')
 CP=$(echo $EXE | awk -F "|" '{print $4}')
 EMAIL=$(echo $EXE | awk -F "|" '{print $5}')
 TELF=$(echo $EXE | awk -F "|" '{print $6}')
 
 CLIENTE_MODIFICADO="${CODIGO}|${CLIENTE}|${DIRECCION}|${POBLACION}|${CP}|${EMAIL}|${TELF}"
 sed -i "s<$CODIGO.*<$CLIENTE_MODIFICADO<" $FICH
 
# echo "El cliente a sido modificado a $CLIENTE_MODIFICADO"
elif  [ "${?}" -eq "1" ]; then
  echo -e "Se va a proceder a eliminar el cliente $CLIENTE con codigo ${CODIGO}\n"
  sed -i "/$CODIGO/d" $FICH
fi

exit 0
  



