#!/bin/bash
#Edita un cliente

. ccodigo
. config


FCLIENTES="clientes.dat"
FFRA="facturas.dat"
TFRA="totales_facturas.dat"
DFRA="public_html"

#creamos el fichero temporal de clientes para leerlos
awk -F "|" '{print $2 }' $FCLIENTES >fich.tmp

function calculaTotales(){
 #Esta funcion calcula los totales de la factura
 #Utilizamos scale para los decimales

 BASE_IMPONIBLE_DESPUES_DTO=$(echo "escale=2; $BASE_IMPONIBLE - $DTO" |bc)
 echo -e "\nBase imponible despues de dto: $BASE_IMPONIBLE_DESPUES_DTO \n"
 
 #Revisamos si existe IRPF
 
 if [ "$IRPF" == "NO" ]; then
   echo "No hay IRPF";
   IRPFN="0";
 else
   IRPFN=$(echo "scale=2; $IRPF/100" |bc) 
  echo "El IRPF Nuevo es: $IRPFN" 
 fi  
 IRPF_CALCULADO=$(echo "scale=2; ($BASE_IMPONIBLE_DESPUES_DTO) * $IRPFN" |bc) 
   echo -e "\nEl IRPF Calculado es: $IRPF_CALCULADO\n"
 

 #Calcula el IVA
 IVAN=$(echo "scale=2; $IVA/100" |bc)
 IVA_CALCULADO=$(echo "scale=2; ($BASE_IMPONIBLE_DESPUES_DTO) * $IVAN"|bc) 
 echo -e "\nEl IVA calculado es $IVA_CALCULADO\n"
 
 #Calcula total Factura
 TOTAL_CALCULADO=$(echo "scale=2; $BASE_IMPONIBLE_DESPUES_DTO - $IRPF_CALCULADO + $IVA_CALCULADO"|bc)
 echo "Total Factura: $TOTAL_CALCULADO"
}


function crearFactura(){
  #Crear el codigo de la FRA a generar
  #Si no hay codigo ingresao
  if [ -z $NUM_FRA ]; then  
   echo -e "Se genera un código "
   CODIGO=$(./ccodigo)
  else
   CODIGO=$NUM_FRA
  fi

  while true ; do 
    EXE=$(yad --text="\nPulsa QUIT para No agregar más lineas al cuerpo *** " --form --geometry="600x600" \
     --field="Cantidad:" "0" \
     --field="Descripcion::TXT" "" \
     --field="Precio:" "" \
     --button=salir!gtk-quit:1 \
     --button=gtk-save:0 \
  )

 
 #Agregar registro al fichero de FFRA hasta que se pulse QUIT!
if [ $? -eq "0" ] ; then
  CANTIDAD=$(echo $EXE |awk -F "|" '{print $1}')
  
  #REVISAMOS QUE CANTIDAD SEA NUMERICO
  CANTIDAD=${CANTIDAD/,/.} 
  echo $CANTIDAD
  
  DESCRIPCION=$(echo $EXE |awk -F "|" '{print $2}')
  echo $DESCRIPCION
  
  PRECIO=$(echo $EXE |awk -F "|" '{print $3}')
  #Cambiamos coma por punto si lo encuentra en cadena
  PRECIO=${PRECIO/,/.}
  echo $PRECIO

  #Revisar los cálculos totales
  #if [ $CANTIDAD -ne "0" ]; then 
    TOTAL=$(echo "scale=2; $CANTIDAD * $PRECIO" |bc)
 # else 
 #   TOTAL=0
 # fi
  echo $TOTAL

  echo "$CODIGO|$CLIENTE|$FECHA|$CANTIDAD|$DESCRIPCION|$PRECIO|$TOTAL" >>$FFRA
  ULTIMO_CODIGO=$(tail -1 $FFRA |awk -F "|" '{print $1}')
  echo -e "\nEl ultimo código es: $ULTIMO_CODIGO\n"
else
  echo -e "No hay más registros para la fra\n"
  break
fi
done
}

totalFactura(){
  #Genera los totales

  BASE_IMPONIBLE=$(awk -v ULTIMO_CODIGO="$ULTIMO_CODIGO" -F "|" '$1==ULTIMO_CODIGO {sum +=$7} END {print sum}' $FFRA)
  echo -e "\nEl código es :${ULTIMO_CODIGO}\nLa Base Imponible es: ${BASE_IMPONIBLE}\n"
  while true  ; do 
    EXE=$(yad --title --"Calculos Globales" --form --geometry="200x400" \
    --field="Base Imponible:" $BASE_IMPONIBLE \
    --field="Descuento:" "0" \
    --field="IRPF::"CB "NO!15!7!9!1!" \
    --field="IVA::"CB "21!10!4" \
    --field="Observaciones" "" \
    --button=gtk-ok:0 )
    if [  "${?}" -eq 0 ] ; then 
     break
    fi
  done

#Revisamos si el ultimo codigo se modifica y cambiamos en el fichero correspondiente


  BASE_IMPONIBLE=$(echo $EXE | awk -F "|" '{print $1}')
  DTO=$(echo $EXE | awk -F "|" '{print $2}')
  IRPF=$(echo $EXE | awk -F "|" '{print $3}')
  IVA=$(echo $EXE | awk -F "|" '{print $4}')
  OBSERVACIONES=$(echo $EXE | awk -F "|" '{print $5}')

  #Pasamos los datos que pone el usuario de comas a puntos para evitar errores
  BASE_IMPONIBLE=${BASE_IMPONIBLE/,/.}
  DTO=${DTO/,/.}

  echo "$ULTIMO_CODIGO|$BASE_IMPONIBLE|$DTO|$IRPF|$IVA|$OBSERVACIONES|$FRA_RECTIFICATIVA" >>$TFRA

}

htmlFRA(){
  #Dibuja una factura en html
  
  #Copia el template original a nº fra_fecha_cliente para poder visualizar 
  #claramente posteriormente el fichero
  FACTURA=${DFRA}/${ULTIMO_CODIGO}.html
  cp ${DFRA}/plantilla_facturas.html ${FACTURA} 
  
 #Revisamos si es una factura rectificativa
  RECTIFICATIVA=$(awk -v ULTIMO_CODIGO="$ULTIMO_CODIGO" -F "|" '$1==ULTIMO_CODIGO {print}' $TFRA |tail -1  |cut -d\| -f7)
  echo -e "Es rectificativa la FRA? : ${RECTIFICATIVA}\n"
  if [ $RECTIFICATIVA == "TRUE" ] ; then
    sed -i "s|<H2>FACTURA|<H2 class='text-danger'>FACTURA RECTIFICATIVA|" $FACTURA
  fi 

  #Cambiar el formato de la fecha 
  #para que no nos de problemas sed  con la barra invertida/
  DATA=$(./cambiarfecha "$FECHA") 
  echo -e "\nLa fecha modificada es $DATA\n"
  
  #Cambiamos todos los campos
  #Primero la parte del empresario y fecha y codigo fra
  sed -i "s/\[FECHA\]/$DATA/g" $FACTURA
  sed -i "s/\[CFRA\]/$ULTIMO_CODIGO/g" $FACTURA
  sed -i "s/\[NOMBRE\]/$NOMBRE/g" $FACTURA
  sed -i "s/\[\NIF\]/$NIF/g" $FACTURA
  sed -i "s/\[DIRECCION\]/$DIRECCION/g" $FACTURA
  sed -i "s/\[POBLACION\]/$POBLACION/g" $FACTURA
  sed -i "s/\[CP\]/$CP/g" $FACTURA
  
  #Ahora cambiamos...
  #DATOS DEL CLIENTE
  CDIRECCION=$(grep "${CLIENTE}" $FCLIENTES |cut -d\| -f3)
  CPOBLACION=$(grep "$CLIENTE" $FCLIENTES |cut -d\| -f4)
  CCP=$(grep "$CLIENTE" $FCLIENTES |cut -d\| -f5)
  CEMAIL=$(grep "$CLIENTE" $FCLIENTES |cut -d\| -f6)
  CTELF=$(grep "$CLIENTE" $FCLIENTES |cut -d\| -f7)
  
  #
  sed -i "s/\[CNOMBRE\]/$CLIENTE/g" $FACTURA
  sed -i "s|\[CDIRECCION\]|$CDIRECCION|g" $FACTURA
  sed -i "s/\[CPOBLACION\]/$CPOBLACION/g" $FACTURA
  sed -i "s/\[\CCP]/$CCP/g" $FACTURA
  sed -i "s/\[\CEMAIL]/$CEMAIL/g" $FACTURA
  sed -i "s/\[\CTELF]/$CTELF/g" $FACTURA
  
  #Ahora cambiamos Cuerpo de la factura
  #buscamos en el fichero de facturas las coincidencias y lo grabamos en temporal
  #sustituimos \n por saltos de linea para preformatear el HTML
  
  awk -v ULTIMO_CODIGO="$ULTIMO_CODIGO" -F "|" '$1==ULTIMO_CODIGO {print}' $FFRA >cuerpo.tmp
  sed -i "s/\\\n/<br>/g" cuerpo.tmp
  sed -i "s|\\\t|\&ensp;|g" cuerpo.tmp
 
  while read line ;do
    CCANTIDAD=$(echo $line |cut -d\| -f4)
    CDESCRIPCION=$(echo $line |cut -d\| -f5)
    CPRECIO_U=$(echo $line|cut -d\| -f6)
    CTOTAL_U=$(echo $line|cut -d\| -f7)
   
   echo -e "\nCantidad: $CCANTIDAD\nDescripcion $CDESCRIPCION\nPrecio Unitario:$CPRECIO_U\nTOTAL:$CTOTAL_U\n"
    
    #Cambiamos los valores en la FRA.
   
    #Valores a dibujar Cambiar puntos por comas
     CCANTIDAD_TO_PRINT=${CCANTIDAD/./,}
     CPRECIO_U_TO_PRINT=${CPRECIO_U/./,}
     CTOTAL_U_TO_PRINT=${CTOTAL_U/./,} 

    #Insertamos antes del valor <!--FINAL_FILA-->
    TEXT="<tr><td class='right col-1 text-center'>$CCANTIDAD_TO_PRINT</td><td class=\"right col-9\"'>$CDESCRIPCION</td><td class='center col-1 text-end'>$CPRECIO_U_TO_PRINT</td><td class='right col-1 text-end'>$CTOTAL_U_TO_PRINT</td></tr>"
   
    echo -e "\nEl texto a agregar es: ${TEXT}\n"
    sed -i "/<!--FINAL_FILA-->.*/i ${TEXT}" $FACTURA
 
 done <cuerpo.tmp
   
  

  #Ahora calculamos los totales para el pie de la factura
  calculaTotales
  
  #Pasamos puntos a comas 
  BASE_IMPONIBLE_TO_PRINT=${BASE_IMPONIBLE/./,}
  DTO_TO_PRINT=${DTO/./,}
  IRPF_CALCULADO_TO_PRINT=${IRPF_CALCULADO/./,}
  IVA_CALCULADO_TO_PRINT=${IVA_CALCULADO/./,}
  TOTAL_CALCULADO_TO_PRINT=${TOTAL_CALCULADO/./,}

  #Ahora Cambiamos los totales
  sed -i "s/\[BASE_IMPONIBLE\]/$BASE_IMPONIBLE_TO_PRINT/g" $FACTURA
  sed -i "s/\[DESCUENTO\]/-$DTO_TO_PRINT/g" $FACTURA
  sed -i "s/\[IRPF\]/-$IRPF_CALCULADO_TO_PRINT/g" $FACTURA
  sed -i "s/\[IVA\]/$IVA_CALCULADO_TO_PRINT/g" $FACTURA
  sed -i "s/\[TOTAL\]/$TOTAL_CALCULADO_TO_PRINT/g" $FACTURA
  
  #Revisamos si en el campo observaciones de config.sh esta definido observaciones globales
  #Si no pasamos valor en observaciones cogemos el parametro global
  if  [ ! -z $OBSERVACIONES ]; then
   sed -i "s/\[OBSERVACIONES\]/$OBSERVACIONES/g" $FACTURA
  else 
   sed -i "s/\[OBSERVACIONES\]/$OBSERVACIONES_PIE_FRA/g" $FACTURA
  fi
     
}



#############################
# PRINCIPIO PROG. PRINCIPAL #
#############################


#utilizar paste para pasarlo en el formato fila en vez de columna
EXE=$(yad  --title="Escoge el cliente" --separator="|" --columns="2" --text="\nDejar Num. Factura sin valor para agregar uno automáticamente\n" --form --item-separator="|" --geometry="300x50" \
--field="Nombre Cliente:"CE  "$(paste -s -d"|" <fich.tmp)" \
--field="FECHA::DT" \
--field="Fra Rectificativa:CHK" \
--field="Num. Factura:" 
)

#Revisamos si se cancela 

if [ "${?}" -ne "0" ]; then
 echo -e "Cancelando...\n Se sale\n " 
 exit 1
fi

#Cogemos los datos introducidos y los guardamos
CLIENTE=$(echo $EXE | awk -F "|" '{print $1}')
FECHA=$(echo $EXE | awk -F "|" '{print $2}')
FRA_RECTIFICATIVA=$(echo $EXE | awk -F "|" '{print $3}')
NUM_FRA=$(echo $EXE | awk -F "|" '{print $4}')

echo -e "\nCliente: $CLIENTE \nFecha: $FECHA\nEs rectificativa?: $FRA_RECTIFICATIVA\nNUM FRA:$NUM_FRA\n"


#Creamos el cuerpo de la fra:
crearFactura

#Creamos los totales de la fra:
totalFactura

#Dibujamos la fra
htmlFRA

#Abrir la fra
x-www-browser public_html/"${ULTIMO_CODIGO}.html"&


#Borramos los ficheros temporales
rm fich.tmp
rm cuerpo.tmp

exit 0
