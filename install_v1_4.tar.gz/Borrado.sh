#!/bin/bash
#Borra los ficheros  de BBDD

declare -a array=("facturas.dat" "totales_facturas.dat" "clientes.dat")
read -p "::: ATENCION SE VAN A BORRAR LAS BBDD Y TODAS LAS FACTURAS::: .\n Esta Acción es irreversible\n DESEA CONTINUAR? (S) " OPCION

#Borramos las fras del directoroio public_html
if [ ${OPCION} == 'S' ] ; then
  echo -e "\nBorrando Facturas...\n" 
  var="plantilla_facturas.html" && find public_html/  -maxdepth 1 ! -name ${var} -exec rm {} \;
  echo -e "\nBorrando BBDD Fra y Clientes"
  for i in "${array[@]}"
    do
      echo -e "Borrando $i\n ..."
      rm $i
    done
else 
  echo -e "\nSe canceló el proceso\n...Saliendo\n"
fi
exit 0
